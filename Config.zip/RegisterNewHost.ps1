<#Author       : Frans Nijskens
# Creation Date: 15 aug 2023
# Usage        : Azure Virtual Desktop Scripted Install

#********************************************************************************
# Date                         Version      Changes
#------------------------------------------------------------------------
# 15 aug 2023                    1.0        Intial Version
#
#>
############################
#    AddSessionHost begin  #
############################
#configuration AddSessionHost
#{
    
##############################
#    AVD Script Parameters   #
##############################
Param (        
    [Parameter(Mandatory=$true)]
        [string]$RegistrationToken          
)

######################
#    AVD Variables   #
######################
$LocalAVDpath            = "c:\temp\AVD\"
$AVDBootURI              = 'https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RWrxrH'
$AVDAgentURI             = 'https://query.prod.cms.rt.microsoft.com/cms/api/am/binary/RWrmXv'
$AVDAgentInstaller       = 'WVD-Agent.msi'
$AVDBootInstaller        = 'WVD-Bootloader.msi'


####################################
#    Test/Create Temp Directory    #
####################################
if((Test-Path c:\temp) -eq $false) {
    Add-Content -LiteralPath C:\New-AVDSessionHost.log "Create C:\temp Directory"
    Write-Host `
        -ForegroundColor Cyan `
        -BackgroundColor Black `
        "creating temp directory"
    New-Item -Path c:\temp -ItemType Directory
}
else {
    Add-Content -LiteralPath C:\New-AVDSessionHost.log "C:\temp Already Exists"
    Write-Host `
        -ForegroundColor Yellow `
        -BackgroundColor Black `
        "temp directory already exists"
}
if((Test-Path $LocalAVDpath) -eq $false) {
    Add-Content -LiteralPath C:\New-AVDSessionHost.log "Create C:\temp\AVD Directory"
    Write-Host `
        -ForegroundColor Cyan `
        -BackgroundColor Black `
        "creating c:\temp\AVD directory"
    New-Item -Path $LocalAVDpath -ItemType Directory
}
else {
    Add-Content -LiteralPath C:\New-AVDSessionHost.log "C:\temp\AVD Already Exists"
    Write-Host `
        -ForegroundColor Yellow `
        -BackgroundColor Black `
        "c:\temp\AVD directory already exists"
}
New-Item -Path c:\ -Name New-AVDSessionHost.log -ItemType File
Add-Content `
-LiteralPath C:\New-AVDSessionHost.log `
"
RegistrationToken = $RegistrationToken
"


#################################
#    Download AVD Componants    #
#################################
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Downloading AVD Boot Loader"
    Invoke-WebRequest -Uri $AVDBootURI -OutFile "$LocalAVDpath$AVDBootInstaller"
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Downloading AVD Agent"
    Invoke-WebRequest -Uri $AVDAgentURI -OutFile "$LocalAVDpath$AVDAgentInstaller"


##############################
#    Prep for AVD Install    #
##############################
#cd $LocalAVDpath 
##############################
#    OS Specific Settings    #
##############################
#$OS = (Get-WmiObject win32_operatingsystem).name
#If(($OS) -match 'server') {
#    Add-Content -LiteralPath C:\New-AVDSessionHost.log "Windows Server OS Detected"
#    write-host -ForegroundColor Cyan -BackgroundColor Black "Windows Server OS Detected"
#}
#Else {
#    Add-Content -LiteralPath C:\New-AVDSessionHost.log "Windows Client OS Detected"
#    write-host -ForegroundColor Cyan -BackgroundColor Black "Windows Client OS Detected"
#    if(($OS) -match 'Windows 10') {
#        write-host `
#            -ForegroundColor Yellow `
#            -BackgroundColor Black  `
#            "Windows 10 detected...skipping to next step"
3        Add-Content -LiteralPath C:\New-AVDSessionHost.log "Windows 10 Detected...skipping to next step"     
#    }    
#}


################################
#    Install AVD Componants    #
################################
cd $LocalAVDpath 
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Installing AVD Bootloader"
$bootloader_deploy_status = Start-Process `
    -FilePath "msiexec.exe" `
    -ArgumentList "/i $AVDBootInstaller", `
        "/quiet", `
        "/qn", `
        "/norestart", `
        "/passive", `
        "/l* $LocalAVDpath\AgentBootLoaderInstall.txt" `
    -Wait `
    -Passthru
$sts = $bootloader_deploy_status.ExitCode
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Installing AVD Bootloader Complete"
Write-Output "Installing RDAgentBootLoader on VM Complete. Exit code=$sts`n"
Wait-Event -Timeout 5
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Installing AVD Agent"
Write-Output "Installing RD Infra Agent on VM $AgentInstaller`n"
$agent_deploy_status = Start-Process `
    -FilePath "msiexec.exe" `
    -ArgumentList "/i $AVDAgentInstaller", `
        "/quiet", `
        "/qn", `
        "/norestart", `
        "/passive", `
        "REGISTRATIONTOKEN=$RegistrationToken", "/l* $LocalAVDpath\AgentInstall.txt" `
    -Wait `
    -Passthru
Add-Content -LiteralPath C:\New-AVDSessionHost.log "AVD Agent Install Complete"
Wait-Event -Timeout 5



##########################################
#    Enable Screen Capture Protection    #
##########################################
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Enable Screen Capture Protection"
Push-Location 
Set-Location "HKLM:\SOFTWARE\Policies\Microsoft\Windows NT\Terminal Services"
New-ItemProperty `
    -Path .\ `
    -Name fEnableScreenCaptureProtection `
    -Value "1" `
    -PropertyType DWord `
    -Force
Pop-Location


##############################
#    Enable Azure AD Join    #
##############################
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Enable Azure AD Join"
Push-Location 
Set-Location HKLM:\SOFTWARE\Microsoft
New-Item `
    -Path HKLM:\SOFTWARE\Microsoft `
    -Name RDInfraAgent `
    -Force
New-Item `
    -Path HKLM:\Software\Microsoft\RDInfraAgent `
    -Name AADJPrivate `
    -Force
Pop-Location

##########################
#    Restart Computer    #
##########################
#Add-Content -LiteralPath C:\New-AVDSessionHost.log "Process Complete - REBOOT"
#Restart-Computer -Force 

##########################
#    AddSessionHost End  #
##########################
Add-Content -LiteralPath C:\New-AVDSessionHost.log "Process Complete - Finished"
#}