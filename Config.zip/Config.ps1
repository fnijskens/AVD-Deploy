configuration AddSessionHost
{
    param
    (    
        [Parameter(mandatory = $true)]
        [string]$RegistrationToken
    )

    $ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

    Node localhost
    {
        LocalConfigurationManager
        {
            RebootNodeIfNeeded = $true
            ConfigurationMode = "ApplyOnly"
        }
               
        Script ExecuteRdAgentInstallClient
        {
           GetScript = {
              return @{'Result' = ''}
           }
           SetScript = {
              & "$using:ScriptPath\RegisterNewHost.ps1" -RegistrationToken=$RegistrationToken
           }
           TestScript = {
               return (Test-path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent")
           }
        }

            
    }
}
