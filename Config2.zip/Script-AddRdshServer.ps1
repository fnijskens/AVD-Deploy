﻿<#

.SYNOPSIS
Creating Hostpool and add sessionhost servers to existing/new Hostpool.

.DESCRIPTION
This script add sessionhost servers to existing/new Hostpool
The supported Operating Systems Windows Server 2016.

.ROLE
Readers

#>
param(
    [Parameter(Mandatory = $true)]
    [string]$AzTenantID,
    [Parameter(mandatory = $true)]
    [string]$HostPoolName,
    [Parameter(mandatory = $true)]
    [string]$ResourceGroupName,
    [Parameter(mandatory = $true)]
    [string]$AppID,
    [Parameter(mandatory = $true)]
    [string]$AppSecret
)

$ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

# Dot sourcing Functions.ps1 file
. (Join-Path $ScriptPath "Functions.ps1")

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

Write-Log -Message "Identifying if this VM is Build >= 1809"
$rdshIs1809OrLaterBool = Is1809OrLater

Write-Log -Message "Creating a folder inside rdsh vm for extracting deployagent zip file"
$DeployAgentLocation = "C:\DeployAgent"
ExtractDeploymentAgentZipFile -ScriptPath $ScriptPath -DeployAgentLocation $DeployAgentLocation

Write-Log -Message "Changing current folder to Deployagent folder: $DeployAgentLocation"
Set-Location "$DeployAgentLocation"

# Checking if RDInfragent is registered or not in rdsh vm
$CheckRegistry = Get-ItemProperty -Path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent" -ErrorAction SilentlyContinue

Write-Log -Message "Checking whether VM was Registered with RDInfraAgent"

if ($CheckRegistry)
{
    Write-Log -Message "VM was already registered with RDInfraAgent, script execution was stopped"
}
else
{
    Write-Log -Message "VM not registered with RDInfraAgent, script execution will continue"


    # Get Hostpool Registration Token
    Write-Log -Message "Checking for existing registration token"
    #Install Pre-Req modules
#    Install-packageProvider -Name NuGet -MinimumVErsion 2.8.5.201 -force
#    Install-Module -Name Az.DesktopVirtualization -AllowClobber -Force
#    Install-Module -Name Az.Accounts -AllowClobber -Force
#    Install-Module -Name Az.Resources -AllowClobber -Force
#    Import-Module -Name Az.DesktopVirtualization

#    #Create credential object to connect to Azure
#    $Creds= New-Object System.Management.Automation.PSCredential($AppID, (ConvertTo-SecureString $AppSecret -AsPlainText -Force))

#    Connect-AzAccount -ServicePrincipal -Credential $Creds -TenantID $AzTenantID

#    $Registered = Get-AzWvdRegistrationInfo -ResourceGroupName "$resourceGroupName" -HostPoolName $HostPoolName
#    if (-not(-Not $Registered.Token)){ 
#        $registrationTokenValidFor = (NEW-TIMESPAN -Start (get-date) -End $Registered.ExpirationTime | select-object Days,Hours,Minutes,Seconds)
#        Write-Log -Message "Registration Token found."
#        Write-Log -Message $registrationTokenValidFor
#    }


 #   if ((-Not $Registered.Token) -or ($Registered.ExpirationTime -le (get-date)))
 #   {
 #       Write-Log -Message "Valid Registration Token not found. Generating new token with 8 hours expiration"
 #       $Registered = New-AzWvdRegistrationInfo -ResourceGroupName $resourceGroupName -HostPoolName $HostPoolName -ExpirationTime (Get-Date).AddHours(8) -ErrorAction #SilentlyContinue
 #   }

    $RegistrationInfoToken = "eyJhbGciOiJSUzI1NiIsImtpZCI6IjQ4Q0Y2MjhENTM5OUYzNTMwQkM5MzI0RjgyMzVFNEY1RkEyOTQxNkIiLCJ0eXAiOiJKV1QifQ.eyJSZWdpc3RyYXRpb25JZCI6ImE4ZTUzNjdjLTNkY2UtNDNhOS04NTNjLTcwYjY4OTg4ZjVjOCIsIkJyb2tlclVyaSI6Imh0dHBzOi8vcmRicm9rZXItZy1ldS1yMC53dmQubWljcm9zb2Z0LmNvbS8iLCJEaWFnbm9zdGljc1VyaSI6Imh0dHBzOi8vcmRkaWFnbm9zdGljcy1nLWV1LXIwLnd2ZC5taWNyb3NvZnQuY29tLyIsIkVuZHBvaW50UG9vbElkIjoiZmYxM2IxYjgtOTViNS00ZDQwLWIzMjUtODcwODZiMDg1YzU2IiwiR2xvYmFsQnJva2VyVXJpIjoiaHR0cHM6Ly9yZGJyb2tlci53dmQubWljcm9zb2Z0LmNvbS8iLCJHZW9ncmFwaHkiOiJFVSIsIkdsb2JhbEJyb2tlclJlc291cmNlSWRVcmkiOiJodHRwczovL2ZmMTNiMWI4LTk1YjUtNGQ0MC1iMzI1LTg3MDg2YjA4NWM1Ni5yZGJyb2tlci53dmQubWljcm9zb2Z0LmNvbS8iLCJCcm9rZXJSZXNvdXJjZUlkVXJpIjoiaHR0cHM6Ly9mZjEzYjFiOC05NWI1LTRkNDAtYjMyNS04NzA4NmIwODVjNTYucmRicm9rZXItZy1ldS1yMC53dmQubWljcm9zb2Z0LmNvbS8iLCJEaWFnbm9zdGljc1Jlc291cmNlSWRVcmkiOiJodHRwczovL2ZmMTNiMWI4LTk1YjUtNGQ0MC1iMzI1LTg3MDg2YjA4NWM1Ni5yZGRpYWdub3N0aWNzLWctZXUtcjAud3ZkLm1pY3Jvc29mdC5jb20vIiwiQUFEVGVuYW50SWQiOiI5YTg2ZDRjZS03MmFmLTQyODYtYjA3MS1kNTgyYjE0YWQ2OTgiLCJuYmYiOjE2OTE0OTcxMDMsImV4cCI6MTY5MzQzMjgwMCwiaXNzIjoiUkRJbmZyYVRva2VuTWFuYWdlciIsImF1ZCI6IlJEbWkifQ.aQujw8LLoez8Xp5AT15Um1h_jAiFsZAAEauY_2_du0SYrqKr_GXE087Q7Tskswwpfi1rEF_GN-fhzg53XcR12yQs4n3ESXI_xPGCRIaPe6f9ZF8Y0n8r00PEx_StdDGb8nTxt6Mp0LSr3mbj5nvNIO6hXhvcqdiUIPLlVbduLJ7xvikqQGsKMXuuz1g4mZHESARQV0qYGrfDoc0AJKCK7_7C8-IjTSfYX7kNTSLo88PQzbr6qxxTiiZoSMuKcgSIqSNFlV7gshRhYC5IK6uG-xpcMjjGv517McmxvX2FWPyR2fbApp0F-mhJv-SWH48AbrvGTvCN4ix5DPmgSnLoSA"

    # Executing DeployAgent psl file in rdsh vm and add to hostpool
    Write-Log "AgentInstaller is $DeployAgentLocation\RDAgentBootLoaderInstall, InfraInstaller is $DeployAgentLocation\RDInfraAgentInstall, SxS is $DeployAgentLocation\RDInfraSxSStackInstall"
    $DAgentInstall = .\DeployAgent.ps1 -AgentBootServiceInstallerFolder "$DeployAgentLocation\RDAgentBootLoaderInstall" `
                                       -AgentInstallerFolder "$DeployAgentLocation\RDInfraAgentInstall" `
                                       -SxSStackInstallerFolder "$DeployAgentLocation\RDInfraSxSStackInstall" `
                                       -EnableSxSStackScriptFolder "$DeployAgentLocation\EnableSxSStackScript" `
                                       -RegistrationToken $RegistrationInfoToken `
                                       -StartAgent $true `
                                       -rdshIs1809OrLater $rdshIs1809OrLaterBool
    
    Write-Log -Message "DeployAgent Script was successfully executed and RDAgentBootLoader,RDAgent,StackSxS installed inside VM for existing hostpool: $HostPoolName`n$DAgentInstall"
}