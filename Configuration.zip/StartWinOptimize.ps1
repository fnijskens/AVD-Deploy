﻿<#
.SYNOPSIS
optimize windows on target VM

.DESCRIPTION
This script will optimize windows 

.PARAMETER Optimizations
Option to optimize windows 10 all of partially
#>
#Requires -Version 4.0

Param(
    [ValidateSet('All','WindowsMediaPlayer','AppxPackages','ScheduledTasks','DefaultUserSettings','Autologgers','Services','NetworkOptimizations','LGPO','DiskCleanup')] 
    [String[]]
    $Optimizations = "All"

)


function Test-IsAdmin {
    ([Security.Principal.WindowsPrincipal] [Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")
}

New-Item -Path C:\deployagent -Name Optimize -ItemType Directory -ErrorAction SilentlyContinue
$LocalPath = "C:\deployagent\Optimize\"

###############################
#    Prep for WVD Optimize    #
###############################
Expand-Archive `
    -LiteralPath "\\wvdfslogixhost.file.core.windows.net\fslogix\Software\Win10_Optimize.zip" `
    -DestinationPath "$Localpath" `
    -Force `
    -Verbose


#################################
#    Run WVD Optimize Script    #
#################################
New-Item -Path C:\deployagent\optimize\ -Name optimize.log -ItemType File -Force
Set-ExecutionPolicy -ExecutionPolicy bypass -Force -Verbose
add-content c:\deployagent\Optimize\Optimize.log "Starting Optimizations"  
& C:\DeployAgent\optimize\Win10_VirtualDesktop_Optimize.ps1 # -Optimizations $Optimizations -Restart -AcceptEULA -Verbose


