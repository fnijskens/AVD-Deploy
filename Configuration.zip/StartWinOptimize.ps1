﻿<#
.SYNOPSIS
optimize windows on target VM

.DESCRIPTION
This script will optimize windows 

.PARAMETER Optimizations
Option to optimize windows 10 all of partially
#>
#Requires -Version 4.0

Param(
    [ValidateSet('All','WindowsMediaPlayer','AppxPackages','ScheduledTasks','DefaultUserSettings','Autologgers','Services','NetworkOptimizations','LGPO','DiskCleanup')] 
    [String[]]
    $Optimizations = "All"

)

$ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

# Dot sourcing Functions.ps1 file
. (Join-Path $ScriptPath "Functions.ps1")

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

$LocalPath = "C:\DeployAgent\Win10_Optimize\"
set-location -path $LocalPath
ExtractWin10OptimizeZipFile -ScriptPath $ScriptPath -DeployLocation $LocalPath
Add-Content -Path c:\deployagent\Win10_Optimize\Optimize.log  -Value "$DateTime extracted extracting Win10Optimize zip in folder inside Deployagen"


#################################
#    Run WVD Optimize Script    #
#################################
#Set-ExecutionPolicy -ExecutionPolicy bypass -Force -Verbose
 Add-Content -Path c:\deployagent\Win10_Optimize\Optimize.log  -value "$DateTime Starting Optimizations"  
 $WinOpt = .\Win10_VirtualDesktop_Optimize.ps1 -Optimizations $Optimizations -Restart -AcceptEULA -Verbose
 Add-Content -Path c:\deployagent\Win10_Optimize\Optimize.log -value "$DateTime Finish Win 10 Optimize"
