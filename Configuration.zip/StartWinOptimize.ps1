﻿<#
.SYNOPSIS
optimize windows on target VM

.DESCRIPTION
This script will optimize windows 

.PARAMETER Optimizations
Option to optimize windows 10 all of partially
#>
#Requires -Version 4.0

Param(
    [ValidateSet('All','WindowsMediaPlayer','AppxPackages','ScheduledTasks','DefaultUserSettings','Autologgers','Services','NetworkOptimizations','LGPO','DiskCleanup')] 
    [String[]]
    $Optimizations = "All"

)

$ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

# Dot sourcing Functions.ps1 file
. (Join-Path $ScriptPath "Functions.ps1")

# Setting ErrorActionPreference to stop script execution when error occurs
$ErrorActionPreference = "Stop"

Write-Log -Message "Creating a folder inside Deployagent for extracting Win10Optimize zip file"
$LocalPath = "C:\DeployAgent\Win10_Optimize\"
ExtractWin10OptimizeZipFile -ScriptPath $ScriptPath -DeployLocation $LocalPath


#################################
#    Run WVD Optimize Script    #
#################################
Write-Log -Message "Start Win 10 Optimize"
New-Item -Path $LocalPath -Name optimize.log -ItemType File -Force
Set-ExecutionPolicy -ExecutionPolicy bypass -Force -Verbose
add-content c:\deployagent\Win10_Optimize\Optimize.log "Starting Optimizations"  
& C:\DeployAgent\Win10_Optimize\Win10_VirtualDesktop_Optimize.ps1 # -Optimizations $Optimizations -Restart -AcceptEULA -Verbose
Write-Log -Message "Finish Win 10 Optimize"

