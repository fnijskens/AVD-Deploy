configuration AddSessionHost
{
    param
    (    
        [Parameter(mandatory = $true)]
        [string]$RegistrationToken
    )

    Node localhost
    {
        Script ExecuteRdAgentInstallClient
        {
            GetScript = {
                return @{'Result' = ''}
            }
            SetScript = {
                & "$using:ScriptPath\Script-AddRdshServer.ps1" -RegistrationToken $using:RegistrationToken
            }
            TestScript = {
                return (Test-path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent")
            }
        }
      
    }
}
