configuration AddSessionHost
{
    param
    (    
        [Parameter(mandatory = $true)]
        [string]$RegistrationToken
    )
    $ScriptPath = [system.io.path]::GetDirectoryName($PSCommandPath)

		if (-not (Test-Path $ScriptPath)))
		{
		    throw "Installer path is not found '$ScriptPath'"
		} 
		else {
	    $ScriptPath = 'c:\temp\'
			if (-not (Test-Path $ScriptPath)))
			{
			    throw "Installer back-up path is not found '$ScriptPath'"
			}
		}
    Node localhost
    {
        Script ExecuteRdAgentInstallClient
        {
            GetScript = {
                return @{'Result' = ''}
            }
            SetScript = {
                & "$using:ScriptPath\Script-AddRdshServer.ps1" -RegistrationToken $using:RegistrationToken
            }
            TestScript = {
                return (Test-path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent")
            }
        }
      
    }
}
