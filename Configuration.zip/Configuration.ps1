configuration AddSessionHost
{
    param
    (    
        [Parameter(mandatory = $true)]
        [string]$HostPoolName,
        [Parameter(mandatory = $true)]
        [string]$ResourceGroup,
        [Parameter(mandatory = $true)]
        [string]$ApplicationGroupName,
        [Parameter(mandatory = $true)]
        [string]$AzTenantID,
        [Parameter(mandatory = $true)]
        [string]$DesktopName,
        [Parameter(mandatory = $true)]
        [string]$AppID,
        [Parameter(mandatory = $true)]
        [string]$AppSecret,
        [Parameter(mandatory = $true)]
        [string]$DefaultUsers,
        [Parameter(mandatory = $true)]
        [string]$vmPrefix,
        [Parameter(mandatory = $true)]
        [string]$RegistrationToken
    )

    Node localhost
    {
        Script ExecuteRdAgentInstallClient
        {
            GetScript = {
                return @{'Result' = ''}
            }
            SetScript = {
                & "$using:ScriptPath\Script-AddRdshServer.ps1" -RegistrationToken $using:RegistrationToken
            }
            TestScript = {
                return (Test-path "Registry::HKEY_LOCAL_MACHINE\SOFTWARE\Microsoft\RDInfraAgent")
            }
        }
      
    }
}
